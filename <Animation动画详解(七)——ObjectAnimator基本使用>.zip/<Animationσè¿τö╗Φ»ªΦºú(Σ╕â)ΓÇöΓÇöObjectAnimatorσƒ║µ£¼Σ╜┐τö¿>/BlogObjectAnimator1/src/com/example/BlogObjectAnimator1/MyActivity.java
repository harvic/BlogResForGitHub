package com.example.BlogObjectAnimator1;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyActivity extends Activity {
    private TextView tv;
    private Button btnStart, btnCancel;
    private MyPointView mPointView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        tv = (TextView) findViewById(R.id.tv);

        btnStart = (Button) findViewById(R.id.btn);
        btnCancel = (Button) findViewById(R.id.btn_cancel);
        mPointView = (MyPointView)findViewById(R.id.pointview);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /**
                 * 一、概述之Alpha
                 */
//                doAlphaAnimation();
                /**
                 * 一、概述之rotationX
                 */
//                doRatateXAnimation();
                /**
                 * 一、概述之rotationY
                 */
//                doRatateYAnimation();
                /**
                 * 一、概述之rotation
                 */
//                doRotateAnimation();
                /**
                 * 一、概述之translationX
                 */
//                doTranslationXAnimation();
                /**
                 * 一、概述之translationY
                 */
//                doTranslationYAnimation();
                /**
                 * 一、概述之scaleX
                 */
//                doScaleXAnimation();
                /**
                 * 一、概述之scaleY
                 */
//                doScaleYAnimation();

                /**
                 * 二、自定义ObjectAnimator属性
                 */
//                doPointViewAnimation();
                /**
                 * 三.1、使用ArgbEvaluator
                 */
                doBackgroundColor();
            }
        });

    }

    /**
     * 一、概述之Alpha
     */
    private void doAlphaAnimation() {
        ObjectAnimator animator = ObjectAnimator.ofFloat(tv, "alpha", 1, 0, 1);
        animator.setDuration(2000);
        animator.start();
    }


    /**
     * 一、概述之rotationX
     */
    private void doRatateXAnimation() {
        ObjectAnimator animator = ObjectAnimator.ofFloat(tv, "rotationX", 0, 180, 0);
        animator.setDuration(2000);
        animator.start();
    }
    /**
     * 一、概述之rotationY
     */
    private void doRatateYAnimation() {
        ObjectAnimator animator = ObjectAnimator.ofFloat(tv, "rotationY", 0, 180, 0);
        animator.setDuration(2000);
        animator.start();
    }
    /**
     * 一、概述之rotation
     */
    private void doRotateAnimation() {
        ObjectAnimator animator = ObjectAnimator.ofFloat(tv, "rotation", 0, 270, 0);
        animator.setDuration(2000);
        animator.start();
    }
    /**
     * 一、概述之translationX
     */
    private void doTranslationXAnimation(){
        ObjectAnimator animator = ObjectAnimator.ofFloat(tv, "translationX", 0, 200, -200,0);
        animator.setDuration(2000);
        animator.start();
    }
    /**
     * 一、概述之translationY
     */
    private void doTranslationYAnimation(){
        ObjectAnimator animator = ObjectAnimator.ofFloat(tv, "translationY", 0, 200, -100,0);
        animator.setDuration(2000);
        animator.start();
    }
    /**
     * 一、概述之scaleX
     */
    private void doScaleXAnimation(){
        ObjectAnimator animator = ObjectAnimator.ofFloat(tv, "scaleX", 0, 3, 1);
        animator.setDuration(2000);
        animator.start();
    }
    /**
     * 一、概述之scaleY
     */
    private void doScaleYAnimation(){
        ObjectAnimator animator = ObjectAnimator.ofInt(tv, "scaleY", 0, 3, 1);
        animator.setDuration(2000);
        animator.start();
    }

    /**
     * 二、自定义ObjectAnimator属性
     */
    private void doPointViewAnimation(){
        ObjectAnimator animator = ObjectAnimator.ofInt(mPointView, "pointRadius", 0, 300, 100);
        animator.setDuration(2000);
        animator.start();
    }

    /**
     * 三.1、使用ArgbEvaluator
     */
    private void doBackgroundColor(){
        ObjectAnimator animator = ObjectAnimator.ofInt(tv, "BackgroundColor", 0xffff00ff, 0xffffff00, 0xffff00ff);
        animator.setDuration(8000);
        animator.setEvaluator(new ArgbEvaluator());
        animator.start();
    }
}
