package com.harvic.BlogValueAnimator4;

/**
 * Created by qijian on 16/1/15.
 */
public class Point {
    private int radius;

    public Point(int radius){
        this.radius = radius;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }
}
